/**
 * Several useful timing source implementations for animations.
 */
package org.jdesktop.core.animation.timing.sources;