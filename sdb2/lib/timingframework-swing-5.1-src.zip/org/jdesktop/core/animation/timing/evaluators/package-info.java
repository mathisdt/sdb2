/**
 * Evaluator implementations for the standard Java numeric types.
 */
package org.jdesktop.core.animation.timing.evaluators;