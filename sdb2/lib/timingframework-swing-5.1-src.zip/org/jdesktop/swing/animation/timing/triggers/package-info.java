/**
 * A simple mechanism for starting animations when specific Swing events occur.
 */
package org.jdesktop.swing.animation.timing.triggers;