package org.jdesktop.swingx;


public class JXTextAreaBeanInfo extends JXPromptBeanInfo {
	public JXTextAreaBeanInfo() {
		super(JXTextArea.class);
	}
}
