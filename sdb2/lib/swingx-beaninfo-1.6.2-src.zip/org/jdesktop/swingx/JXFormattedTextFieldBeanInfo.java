package org.jdesktop.swingx;


public class JXFormattedTextFieldBeanInfo extends JXPromptBeanInfo {
	public JXFormattedTextFieldBeanInfo() {
		super(JXFormattedTextField.class);
	}
}
