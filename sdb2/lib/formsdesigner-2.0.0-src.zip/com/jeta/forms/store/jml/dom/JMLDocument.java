package com.jeta.forms.store.jml.dom;


public interface JMLDocument {

	public JMLNode createNode(String nodeName);

	public JMLNode createTextNode(String string);

}
