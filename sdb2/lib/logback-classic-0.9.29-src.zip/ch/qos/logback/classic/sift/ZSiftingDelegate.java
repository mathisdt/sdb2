//
// Generated stub from file:/C:/home/ceki/logback/logback-classic/src/main/groovy/ch/qos/logback/classic/sift/ZSiftingDelegate.groovy
//

package ch.qos.logback.classic.sift;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import ch.qos.logback.core.spi.ContextAwareBase;
import ch.qos.logback.core.Appender;
import ch.qos.logback.classic.gaffer.AppenderDelegate;
import ch.qos.logback.core.util.StatusPrinter;

/**
 * @author Ceki G&uuml;c&uuml;
 */
public class ZSiftingDelegate
    extends ContextAwareBase
    implements groovy.lang.GroovyObject
{
    private java.lang.String key = null;
    public java.lang.String getKey() {
        throw new InternalError("Stubbed method");
    }
    public void setKey(java.lang.String value) {
        throw new InternalError("Stubbed method");
    }

    private java.lang.String value = null;
    public java.lang.String getValue() {
        throw new InternalError("Stubbed method");
    }
    public void setValue(java.lang.String value) {
        throw new InternalError("Stubbed method");
    }

    /**
     * Magic constructor
     */
    private ZSiftingDelegate(java.lang.Void void0, java.lang.Void void1, java.lang.Void void2) {
        throw new InternalError("Stubbed method");
    }

    public ZSiftingDelegate(java.lang.String key, java.lang.String value) {
        this((java.lang.Void)null, (java.lang.Void)null, (java.lang.Void)null);
        throw new InternalError("Stubbed method");
    }

    public Appender appender(java.lang.String name, Class clazz, Closure closure) {
        throw new InternalError("Stubbed method");
    }

    public groovy.lang.MetaClass getMetaClass() {
        throw new InternalError("Stubbed method");
    }

    public void setMetaClass(groovy.lang.MetaClass metaClass) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object invokeMethod(java.lang.String name, java.lang.Object args) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object getProperty(java.lang.String name) {
        throw new InternalError("Stubbed method");
    }

    public void setProperty(java.lang.String name, java.lang.Object value) {
        throw new InternalError("Stubbed method");
    }
}
