//
// Generated stub from file:/C:/home/ceki/logback/logback-classic/src/main/groovy/ch/qos/logback/classic/gaffer/GafferConfigurator.groovy
//

package ch.qos.logback.classic.gaffer;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.core.util.ContextUtil;
import ch.qos.logback.core.joran.util.ConfigurationWatchListUtil;

/**
 * Logback: the reliable, generic, fast and flexible logging framework.
 * Copyright (C) 1999-2010, QOS.ch. All rights reserved.
 * 
 * This program and the accompanying materials are dual-licensed under
 * either the terms of the Eclipse Public License v1.0 as published by
 * the Eclipse Foundation
 * 
 * or (per the licensee's choosing)
 * 
 * under the terms of the GNU Lesser General Public License version 2.1
 * as published by the Free Software Foundation.
 */
public class GafferConfigurator
    extends java.lang.Object
    implements groovy.lang.GroovyObject
{
    private LoggerContext context = null;
    public LoggerContext getContext() {
        throw new InternalError("Stubbed method");
    }
    public void setContext(LoggerContext value) {
        throw new InternalError("Stubbed method");
    }

    /**
     * Magic constructor
     */
    private GafferConfigurator(java.lang.Void void0, java.lang.Void void1, java.lang.Void void2) {
        throw new InternalError("Stubbed method");
    }

    public GafferConfigurator(LoggerContext context) {
        this((java.lang.Void)null, (java.lang.Void)null, (java.lang.Void)null);
        throw new InternalError("Stubbed method");
    }

    protected void informContextOfURLUsedForConfiguration(URL url) {
        throw new InternalError("Stubbed method");
    }

    public void run(URL url) {
        throw new InternalError("Stubbed method");
    }

    public void run(File file) {
        throw new InternalError("Stubbed method");
    }

    public void run(java.lang.String dslText) {
        throw new InternalError("Stubbed method");
    }

    public groovy.lang.MetaClass getMetaClass() {
        throw new InternalError("Stubbed method");
    }

    public void setMetaClass(groovy.lang.MetaClass metaClass) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object invokeMethod(java.lang.String name, java.lang.Object args) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object getProperty(java.lang.String name) {
        throw new InternalError("Stubbed method");
    }

    public void setProperty(java.lang.String name, java.lang.Object value) {
        throw new InternalError("Stubbed method");
    }
}
