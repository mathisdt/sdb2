//
// Generated stub from file:/C:/home/ceki/logback/logback-classic/src/main/groovy/ch/qos/logback/classic/gaffer/PropertyUtil.groovy
//

package ch.qos.logback.classic.gaffer;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.lang.reflect.Method;
import java.beans.Introspector;

/**
 * @author Ceki G&uuml;c&uuml;
 */
public class PropertyUtil
    extends java.lang.Object
    implements groovy.lang.GroovyObject
{
    static public boolean hasAdderMethod(java.lang.Object obj, java.lang.String name) {
        throw new InternalError("Stubbed method");
    }

    static public NestingType nestingType(java.lang.Object obj, java.lang.String name) {
        throw new InternalError("Stubbed method");
    }

    static public void attach(NestingType nestingType, java.lang.Object component, java.lang.Object subComponent, java.lang.String name) {
        throw new InternalError("Stubbed method");
    }

    static public java.lang.String transformFirstLetter(java.lang.String s, Closure closure) {
        throw new InternalError("Stubbed method");
    }

    static public java.lang.String upperCaseFirstLetter(java.lang.String s) {
        throw new InternalError("Stubbed method");
    }

    public groovy.lang.MetaClass getMetaClass() {
        throw new InternalError("Stubbed method");
    }

    public void setMetaClass(groovy.lang.MetaClass metaClass) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object invokeMethod(java.lang.String name, java.lang.Object args) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object getProperty(java.lang.String name) {
        throw new InternalError("Stubbed method");
    }

    public void setProperty(java.lang.String name, java.lang.Object value) {
        throw new InternalError("Stubbed method");
    }
}
