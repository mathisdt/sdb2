//
// Generated stub from file:/C:/home/ceki/logback/logback-classic/src/main/groovy/ch/qos/logback/classic/gaffer/ComponentDelegate.groovy
//

package ch.qos.logback.classic.gaffer;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import ch.qos.logback.core.spi.ContextAwareBase;
import ch.qos.logback.core.spi.LifeCycle;
import ch.qos.logback.core.spi.ContextAware;
import ch.qos.logback.core.joran.spi.NoAutoStartUtil;

/**
 * @author Ceki G&uuml;c&uuml;
 */
public class ComponentDelegate
    extends ContextAwareBase
    implements groovy.lang.GroovyObject
{
    final private java.lang.Object component = null;
    final public java.lang.Object getComponent() {
        throw new InternalError("Stubbed method");
    }

    final private List fieldsToCaccade = null;
    final public List getFieldsToCaccade() {
        throw new InternalError("Stubbed method");
    }

    /**
     * Magic constructor
     */
    private ComponentDelegate(java.lang.Void void0, java.lang.Void void1, java.lang.Void void2) {
        throw new InternalError("Stubbed method");
    }

    public ComponentDelegate(java.lang.Object component) {
        this((java.lang.Void)null, (java.lang.Void)null, (java.lang.Void)null);
        throw new InternalError("Stubbed method");
    }

    public java.lang.String getLabel() {
        throw new InternalError("Stubbed method");
    }

    public java.lang.String getLabelFistLetterInUpperCase() {
        throw new InternalError("Stubbed method");
    }

    public void methodMissing(java.lang.String name, java.lang.Object args) {
        throw new InternalError("Stubbed method");
    }

    public void cascadeFields(ComponentDelegate subDelegate) {
        throw new InternalError("Stubbed method");
    }

    public void injectParent(java.lang.Object subComponent) {
        throw new InternalError("Stubbed method");
    }

    public void propertyMissing(java.lang.String name, java.lang.Object value) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object analyzeArgs(java.lang.Object[] args) {
        throw new InternalError("Stubbed method");
    }

    public Class parseClassArgument(java.lang.Object arg) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.String parseNameArgument(java.lang.Object arg) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.String getComponentName() {
        throw new InternalError("Stubbed method");
    }

    public groovy.lang.MetaClass getMetaClass() {
        throw new InternalError("Stubbed method");
    }

    public void setMetaClass(groovy.lang.MetaClass metaClass) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object invokeMethod(java.lang.String name, java.lang.Object args) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object getProperty(java.lang.String name) {
        throw new InternalError("Stubbed method");
    }

    public void setProperty(java.lang.String name, java.lang.Object value) {
        throw new InternalError("Stubbed method");
    }
}
