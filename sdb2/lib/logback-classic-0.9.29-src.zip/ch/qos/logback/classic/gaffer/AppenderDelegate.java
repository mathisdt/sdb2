//
// Generated stub from file:/C:/home/ceki/logback/logback-classic/src/main/groovy/ch/qos/logback/classic/gaffer/AppenderDelegate.groovy
//

package ch.qos.logback.classic.gaffer;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import ch.qos.logback.core.Appender;
import ch.qos.logback.core.spi.ContextAwareBase;

/**
 * @author Ceki G&uuml;c&uuml;
 */
public class AppenderDelegate
    extends ComponentDelegate
    implements groovy.lang.GroovyObject
{
    /**
     * Magic constructor
     */
    private AppenderDelegate(java.lang.Void void0, java.lang.Void void1, java.lang.Void void2) {
        super((Appender)null);

        throw new InternalError("Stubbed method");
    }

    public AppenderDelegate(Appender appender) {
        this((java.lang.Void)null, (java.lang.Void)null, (java.lang.Void)null);
        throw new InternalError("Stubbed method");
    }

    public java.lang.String getLabel() {
        throw new InternalError("Stubbed method");
    }

    public groovy.lang.MetaClass getMetaClass() {
        throw new InternalError("Stubbed method");
    }

    public void setMetaClass(groovy.lang.MetaClass metaClass) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object invokeMethod(java.lang.String name, java.lang.Object args) {
        throw new InternalError("Stubbed method");
    }

    public java.lang.Object getProperty(java.lang.String name) {
        throw new InternalError("Stubbed method");
    }

    public void setProperty(java.lang.String name, java.lang.Object value) {
        throw new InternalError("Stubbed method");
    }
}
